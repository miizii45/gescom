


$(document).ready(function() {
	$('#example').pageMe({
	pagerSelector: '#developer_page',
	showPrevNext: true,
	hidePageNumbers: false,
	perPage: 3
	});
	});